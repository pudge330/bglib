bglib.fn.toProperCase = function(str) {
    return bglib.fn.toCamelCase(str).uppercaseFirst();
};