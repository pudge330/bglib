bglib.setRegisteredModule = function(n, m) {
    _bglib.modules[n] = m;
};