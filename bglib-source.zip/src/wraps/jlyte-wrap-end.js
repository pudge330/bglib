bglib.jLyte.bglib = function() {
	return bglib;
};
return bglib.jLyte;}));