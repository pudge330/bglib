/*! @license
 *
 * bglib v1.0
 * https://github.com/pudge330/bglib
 *
 * Copyright 2019
 * Released under the MIT license
 * https://github.com/pudge330/bglib/blob/master/LICENSE
 */

/*! @license
 * 
 * JavaScript Cookie v2.2.0
 * https://github.com/js-cookie/js-cookie
 *
 * Copyright 2006, 2015 Klaus Hartl & Fagner Brack
 * Released under the MIT license
 * https://github.com/js-cookie/js-cookie/blob/master/LICENSE
 */
