bglib.fn.formatPrice = function(amount) {
    return bglib.fn.formatDecimal(amount, 2);
};