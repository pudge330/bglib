/*! @license
 *
 * jLyte - bglib v1.0
 * https://github.com/pudge330/bglib
 *
 * Copyright 2019
 * Released under the MIT license
 * https://github.com/pudge330/bglib/blob/master/LICENSE
 */
